"""
Infrastructure package - External implementations.
"""
