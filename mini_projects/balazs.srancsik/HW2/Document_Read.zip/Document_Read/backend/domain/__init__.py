"""
Domain package - Core business entities and interfaces.
"""
